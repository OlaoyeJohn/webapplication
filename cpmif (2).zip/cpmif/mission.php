<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="fcf.default.css" rel="stylesheet">
    <link href="fcf.default-custom.css" rel="stylesheet">
    <link rel="stylesheet" href="stylesheet.css">

    <title>Mission</title>
    
</head>
<body>
<div class="menu-bar">
    <ul>
    <li class="active"><a href="index.php"><i class="fa fa-home"></i>Home</a></li>
    <li><a href="#"><i class="fa fa-user"></i>About Us</a>
        <div class="sub-menu-1">
            <ul>
                <li><a href="mission.php">Mission/Vision</a></li>
               <!-- <li><a href="#">Vision</a></li> -->
                <li><a href="team.php">Team</a></li>
            </ul>
        </div>
    </li>

    <li><a href="#"><i class="fa fa-clone"></i>Services</a>
    <div class="sub-menu-1">
            <ul>
                <li><a href="housefurniture.php">House Furniture</a></li>
                <li><a href="officefurniture.php">Office Furniture</a></li>
                
            </ul>
        </div>
    
    </li>
    <li><a href="contact.php"><i class="fa fa-phone"></i>Contact</a></li>
    </ul>
    </div>
<div class="row">
    <h3>Who we are?</h3>
    <p>
    On the other hand, we denounce with righteous indignation and dislike men who are so beguiled and demoralized by the charms of pleasure of the moment, so blinded by desire, that they cannot foresee 
    the pain and trouble that are bound to ensue; and equal blame belongs to those who fail in their duty through weakness of will, which is the same as saying through shrinking from toil and pain. These cases are perfectly simple and easy to distinguish. In a free hour, when our power of choice is untrammelled and when nothing prevents our being able to do what we like best, every pleasure is to be welcomed and every pain avoided. But in certain circumstances and owing to the claims of duty or the obligations of business it will frequently occur that pleasures have to be repudiated and annoyances accepted. The wise man therefore always holds in these matters to this principle of selection: he rejects pleasures to secure other greater pleasures, or else he endures pains to avoid worse pains.
    </p>
</div>



</body>
</html>
