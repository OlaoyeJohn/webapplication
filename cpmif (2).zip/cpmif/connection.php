<?php
// database connection code
// $con = mysqli_connect('localhost', 'database_user', 'database_password','database');
$servername = "localhost";
$username = "root";
$password = "";
$dbName = "contact_db";
// Create connection



$con = mysqli_connect($servername, $username, $password, $dbName);



// get the post records
$txtName = $_POST['txtName'];
$txtEmail = $_POST['txtEmail'];
$txtPhone = $_POST['txtPhone'];
$txtMessage = $_POST['txtMessage'];

// database insert SQL code
$sql = "INSERT INTO contact_tbl (fldName, fldEmail, fldPhone, fldMessage) VALUES ('$txtName', '$txtEmail', '$txtPhone', '$txtMessage');";

// insert in database 
$rs = mysqli_query($con, $sql);

if($rs)
{
	echo "Contact Records Inserted";
} else {
    echo "not processed";
}

?>