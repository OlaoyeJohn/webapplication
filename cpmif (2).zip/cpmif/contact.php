<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="fcf.default.css" rel="stylesheet">
    <link href="fcf.default-custom.css" rel="stylesheet">
    <link rel="stylesheet" href="stylesheet.css">

    <title>Contact Us</title>
    
</head>
<body>
<div class="menu-bar">
    <ul>
    <li class="active"><a href="index.php"><i class="fa fa-home"></i>Home</a></li>
    <li><a href="#"><i class="fa fa-user"></i>About Us</a>
        <div class="sub-menu-1">
            <ul>
                <li><a href="mission.php">Mission/Vision</a></li>
               <!-- <li><a href="#">Vision</a></li> -->
                <li><a href="team.php">Team</a></li>
            </ul>
        </div>
    </li>

    <li><a href="#"><i class="fa fa-clone"></i>Services</a>
    <div class="sub-menu-1">
            <ul>
                <li><a href="housefurniture.php">House Furniture</a></li>
                <li><a href="officefurniture.php">Office Furniture</a></li>
                
            </ul>
        </div>
    
    </li>
    <li><a href="contact.php"><i class="fa fa-phone"></i>Contact</a></li>
    <li><a href="dashboard.php"><i class="fa fa-phone"></i>Employee Dashboard</a></li>
    </ul>
    </div>
<div class="fcf-body">
    <div class="fcf-form-wrap">
    <form method="post" action="connection.php">
                    <div>
                        <label for="Name">Your name</label>
                        <div >
                            <input type="text" name="txtName" >
                        </div>
                    </div>
                    <div >
                        <label for="Email" >Your email address</label>
                        <div>
                            <input type="email" name="txtEmail" >
                        </div>
                    </div>
                    <div>
                        <label for="Phone" >Your phone number (optional)</label>
                        <div>
                            <input type="text" name="txtPhone" >
                        </div>
                    </div>
                    <div>
                        <label for="Message" >Your message</label>
                        <div >
                            <textarea name="txtMessage" ></textarea>
                        </div>
                    </div>
                    <div ></div>
                    <div >
                        <div >
                            <button name="submit" type="submit" >Send Message</button>
                        </div>
                    </div>
                </form>

    </div>
</div>

               
           
    
</body>
</html>