<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="fcf.default.css" rel="stylesheet">
    <link href="fcf.default-custom.css" rel="stylesheet">
    <link rel="stylesheet" href="stylesheet.css">

    <title>House Furniture</title>
    
</head>
<body>
<div class="menu-bar">
    <ul>
    <li class="active"><a href="index.php"><i class="fa fa-home"></i>Home</a></li>
    <li><a href="#"><i class="fa fa-user"></i>About Us</a>
        <div class="sub-menu-1">
            <ul>
                <li><a href="mission.php">Mission/Vision</a></li>
               <!-- <li><a href="#">Vision</a></li> -->
                <li><a href="team.php">Team</a></li>
            </ul>
        </div>
    </li>

    <li><a href="#"><i class="fa fa-clone"></i>Services</a>
    <div class="sub-menu-1">
            <ul>
                <li><a href="housefurniture.php">House Furniture</a></li>
                <li><a href="officefurniture.php">Office Furniture</a></li>
                <li><a href="kitchenware.php">Kitchenware</a></li>
                <li><a href="lightfixture.php">Light Fixtures</a></li>
            </ul>
        </div>
    
    </li>
    <li><a href="contact.php"><i class="fa fa-phone"></i>Contact</a></li>
    </ul>
    </div>
  
</body>
</html>
