<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Our Team</title>
    <link rel="stylesheet" href="stylesheet.css">
</head>
<body>
<div class="menu-bar">
    <ul>
    <li class="active"><a href="index.php"><i class="fa fa-home"></i>Home</a></li>
    <li><a href="#"><i class="fa fa-user"></i>About Us</a>
        <div class="sub-menu-1">
            <ul>
                <li><a href="mission.php">Mission/Vision</a></li>
               <!-- <li><a href="#">Vision</a></li> -->
                <li><a href="team.php">Our Team</a></li>
            </ul>
        </div>
    </li>

    <li><a href="#"><i class="fa fa-clone"></i>Services</a>
    <div class="sub-menu-1">
            <ul>
                <li><a href="housefurniture.php">House Furniture</a></li>
                <li><a href="officefurniture.php">Office Furniture</a></li>
                
            </ul>
        </div>
    
    </li>
    <li><a href="#"><i class="fa fa-phone"></i>Contact</a></li>
    <li><a href="dashboard.php"><i class="fa fa-user"></i>Employee Dashboard</a></li>
    </ul>
    </div>
    <div>
        <h2 id="h1">Our Team Member</h2>
    </div>
<div class="row">
  <div class="column">
    <div class="card">
      <h3>John Olaoye</h3>
      <img src="images/john.png" alt="John">
      <p>Some text</p>
      <p>Some text</p>
    </div>
  </div>

  <div class="column">
    <div class="card">
      <h3>Essie Githang'a</h3>
      <img src="images/Essie_modified.png" alt="Essie">
      <p>Some Text Here</p>
      
    </div>
  </div>
  
  <div class="column">
    <div class="card">
      <h3>Joram Kabach</h3>
      <img src="images/joram_modified.png" alt="Joram">
      <p>Some Text Here</p>
      <p>Some text</p>
    </div>
  </div>
  
</div>


</body>
</html>